function hello() {
  alert("Дякую, що цікавишся моїм сайтом!");
}